#!/usr/bin/perl

######################################################################################
#                                                                                    #
#                                       iSiMPRe                                      #
#                                                                                    #
#             Systematic analysis of somatic mutations driving cancer:               #
#           Uncovering functional protein regions in disease development             #
# Balint Meszaros, Andras Zeke, Attila Remenyi, Istvan Simon and Zsuzsanna Dosztanyi #
#     Institute of Enzymology, Hungarian Academy of Sciences, Budapest, Hungary      #  
#                 Eotvos Lorand University, Budapest, Hungary                        #
#                                                                                    #
######################################################################################

use warnings;
use strict;
use Text::NSP::Measures::2D::Fisher::left;
use POSIX;

###########################
# Set variables
###########################

my $seed_region_length_s=7;
my $seed_region_length_m=10;
my $seed_region_length_l=30;
my $probability_cutoff=0.049;
my $max_deletion_probability=0.05;

my $min_extension=10;
my $min_length_ratio=1.25;
my $max_pval_ratio=0.1;
my $pval_tolerance_base=0.5;

my $tolerated_mutation_freq_drop_in_extension=1.02;
my $practically_zero=10e-290;

if(($#ARGV!=3)&&($#ARGV!=4)) {die "Usage: $0 (protein name) (missense mutation data file) (indel mutation data file) (protein sequence file in FASTA format) (cDNA sequence file in FASTA format - optional)\n"}

my $low_complexity_filter=1;

chomp @ARGV;
my $id=$ARGV[0];
my $missense_mut_file=$ARGV[1];
my $indel_mut_file=$ARGV[2];
my $seq_file=$ARGV[3];
my $seq_file_cdna;
if($ARGV[4]) {$seq_file_cdna=$ARGV[4]}
if(!-e $missense_mut_file) {die "Mutation file $missense_mut_file not found, aborting.\n"}
if(!-e $indel_mut_file) {die "Mutation file $indel_mut_file not found, aborting.\n"}
if(!-e $seq_file) {die "Sequence file $seq_file not found, aborting.\n"}
if((!$seq_file_cdna)||(!-e $seq_file_cdna)) {
	print STDERR "cDNA sequence file not specified/found, proceeding without low complexity filtering.\n";
	$low_complexity_filter=0;
}

###########################
# Read protein sequence
###########################

my $seq;
open(SEQ,$seq_file) || die "Cannot open $seq_file\n";
foreach my $line (<SEQ>) {
	if($line=~/^>/) {next;}
	$seq.=$line;
}
close(SEQ);
$seq=~s/\s+//g;
$seq=~s/\*//g;


#########################################
# Run TRF on cDNA sequence, if possible
#########################################

my $trf_prog=$0;
if(($trf_prog!~/^\//)&&($trf_prog!~/^\./)) {$trf_prog='./'.$trf_prog}
$trf_prog=~s/iSiMPRe.pl//;
$trf_prog.='TRF/trf407b.linux64';

if(!-e $trf_prog) {
	print STDERR "Cannot find $trf_prog, proceeding without low complexity filtering.\n";
	$low_complexity_filter=0;
}

my @trf_boundaries;
if($low_complexity_filter==1) {
	# generate TRF output file
	`$trf_prog $seq_file_cdna 2 10 10 80 10 30 50 -h -m`;
	# check if file generation was successful
	my @tmp=split('/',$seq_file_cdna);
	my $trf_fn=$tmp[-1].'.2.10.10.80.10.30.50.mask';
	if(!-e $trf_fn) {
		print STDERR "Generating TRF file $trf_fn was unsuccessful, proceeding without low complexity filtering.\n";
		$low_complexity_filter=0;
	}
	# get boundaries for low complexity regions
	if($low_complexity_filter==1) {
		my $trf_seq_cdna;
		open(TRF,$trf_fn) || die "Cannot open $trf_fn\n";
		while(my $l=<TRF>) {
			if($l=~/^>/) {next;}
			chomp $l;
			$trf_seq_cdna.=$l;
		}	
		close(TRF);

		while($trf_seq_cdna=~/N+/g) {
			my $bounds=(floor(length($`)/3)+1).'-'.(ceil((length($`)+length($&))/3)+1);
			push(@trf_boundaries,$bounds);
		}
	}
}
# Create dummy sequence containinng complexity info
my @seq_trf;
my $seq_trf;
for(my $i=1;$i<=length($seq);$i++) {$seq_trf[$i]='.'}
for(my $i=0;$i<@trf_boundaries;$i++) {
	$trf_boundaries[$i]=~/-/;
	for(my $j=$`;$j<=$';$j++) {if($seq_trf[$j]) {$seq_trf[$j]='x'}}
}
for(my $i=1;$i<@seq_trf;$i++) {$seq_trf.=$seq_trf[$i]}
print STDERR "\n";

###########################
# Read mutations
###########################

my @missense_mutations;
my @missense_mutations_full_info;
my $total_missense_mutations=0;

my @insertion_mutations;
my @insertion_mutations_full_info;
my $total_insertion_mutations=0;

my @deletion_mutations;
my @deletion_mutations_full_info;
my $total_deletion_mutations=0;

for(my $i=1;$i<=length($seq);$i++) {$missense_mutations[$i]=0}
for(my $i=1;$i<=length($seq);$i++) {$insertion_mutations[$i]=0}

my @missense_hits=`grep -P "^$id\\s" $missense_mut_file`;
my @indel_hits=`grep -P "^$id\\s" $indel_mut_file`;

if((!@missense_hits)&&(!@indel_hits)) {die "No mutations found for $id, nothing to do.\n"}

# Read missense mutations
my $n=0;
foreach my $line (@missense_hits) {
	chomp $line;
	my @tmp=split('\t',$line);
	if(substr($seq_trf,$tmp[1]-1,1) eq 'x') {next;} # filter for low complexity
	$missense_mutations[$tmp[1]]++;
	$missense_mutations_full_info[$n]{pos}=$tmp[1];
	$missense_mutations_full_info[$n]{tissue}=$tmp[3];
	$n++;
}
for(my $i=1;$i<@missense_mutations;$i++) {$total_missense_mutations+=$missense_mutations[$i]}
my $average_missense_mut_per_pos=$total_missense_mutations/length($seq);

# Read indel mutations
my $total_deleted_residues=0;
for(my $i=0;$i<@indel_hits;$i++) {
	my @tmp=split('\t',$indel_hits[$i]);
	
	# filter for low complexity
	my $pos=$tmp[1];
	$pos=~/-/;
	my $start=$`;
	my $end=$';
	my $xs=0;
	for(my $i=$start;$i<=$end;$i++) {if(substr($seq_trf,$i-1,1)=~/x/i) {$xs++}}
	if($xs>=(($end-$start+1)/2)) {next;}
	
	if($tmp[2]=~/del/) {
		$tmp[1]=~/-/;
		my $start=$`;
		my $end=$';
		$deletion_mutations[$#deletion_mutations+1]{start}=$start;
		$deletion_mutations[$#deletion_mutations]{end}=$end;
		$deletion_mutations[$#deletion_mutations]{length}=$end-$start+1;
		$total_deleted_residues+=$end-$start+1;
		$deletion_mutations_full_info[$#deletion_mutations_full_info+1]{start}=$start;
		$deletion_mutations_full_info[$#deletion_mutations_full_info]{end}=$end;
		$deletion_mutations_full_info[$#deletion_mutations_full_info]{tissue}=$tmp[3];
	}
	if($tmp[2]=~/ins/) {
		$tmp[1]=~/-/;
		my $start=$`;
		$insertion_mutations[$start]++;
		$insertion_mutations_full_info[$#insertion_mutations_full_info+1]{pos}=$start;
		$insertion_mutations_full_info[$#insertion_mutations_full_info]{tissue}=$tmp[3];
	}
}

for(my $i=1;$i<@insertion_mutations;$i++) {$total_insertion_mutations+=$insertion_mutations[$i]}
my $average_insertion_mut_per_pos=$total_insertion_mutations/length($seq);

$total_deletion_mutations=$#deletion_mutations+1;
my $average_deletion_mut_per_pos=$total_deletion_mutations/length($seq);

if(($total_missense_mutations<2)&&($total_insertion_mutations<2)&&($total_deletion_mutations<2)) {exit;}

my $total_missense_mutations_all=$total_missense_mutations;
my $average_missense_mut_per_pos_all=$average_missense_mut_per_pos;

my $total_insertion_mutations_all=$total_insertion_mutations;
my $average_insertion_mut_per_pos_all=$average_insertion_mut_per_pos;


########################################
# Read full deletion overlap p-values
########################################

my @del_full_overlap_p;
get_del_full_overlap_p(length($seq),\@deletion_mutations,\@deletion_mutations_full_info,\@del_full_overlap_p);

##########################
# Search for regions
##########################

my @regions_s;
my @regions_m;
my @regions_l;
my @final_regions;
my @final_region_list;

for(my $i=1;$i<=length($seq);$i++) {
	$regions_s[$i]=0;
	$regions_m[$i]=0;
	$regions_l[$i]=0;
	$final_regions[$i]=0;
}

# Calculating regions with small seed
my @region_list_s;
scan_for_regions($seed_region_length_s,
		length($seq),
		\@regions_s,
		$probability_cutoff,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues
		);
format_regions_vector_to_list(\@regions_s,\@region_list_s);
get_p_values_for_region_list(\@region_list_s,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));

# Calculating regions with medium seed
my @region_list_m;
scan_for_regions($seed_region_length_m,
		length($seq),
		\@regions_m,
		$probability_cutoff,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues
		);
format_regions_vector_to_list(\@regions_m,\@region_list_m);
get_p_values_for_region_list(\@region_list_m,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));

# Calculating regions with large seed
my @region_list_l;
scan_for_regions($seed_region_length_l,
		length($seq),
		\@regions_l,
		$probability_cutoff,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues
		);
format_regions_vector_to_list(\@regions_l,\@region_list_l);
get_p_values_for_region_list(\@region_list_l,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));

# Combine small and medium regions
amalgamate(\@region_list_s,
	\@region_list_m,
	\@missense_mutations,
	$total_missense_mutations,
	$average_missense_mut_per_pos,
	\@insertion_mutations,
	$total_insertion_mutations,
	$average_insertion_mut_per_pos,
	\@deletion_mutations,
	$total_deleted_residues,
	length($seq),
	$min_extension,
	$min_length_ratio,
	$max_pval_ratio,
	$pval_tolerance_base);
my @regions_sm;
for(my $i=1;$i<=length($seq);$i++) {$regions_sm[$i]=0}
for(my $i=0;$i<@region_list_s;$i++) {write_region($region_list_s[$i]{start},$region_list_s[$i]{end},\@regions_sm)}
for(my $i=0;$i<@region_list_m;$i++) {write_region($region_list_m[$i]{start},$region_list_m[$i]{end},\@regions_sm)}
my @region_list_sm;
format_regions_vector_to_list(\@regions_sm,\@region_list_sm);
get_p_values_for_region_list(\@region_list_sm,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));

# Further combine with large regions
amalgamate(\@region_list_sm,
	\@region_list_l,
	\@missense_mutations,
	$total_missense_mutations,
	$average_missense_mut_per_pos,
	\@insertion_mutations,
	$total_insertion_mutations,
	$average_insertion_mut_per_pos,
	\@deletion_mutations,
	$total_deleted_residues,
	length($seq),
	$min_extension,
	$min_length_ratio,
	$max_pval_ratio,
	$pval_tolerance_base);
my @regions_final;
for(my $i=1;$i<=length($seq);$i++) {$regions_final[$i]=0}
for(my $i=0;$i<@region_list_sm;$i++) {write_region($region_list_sm[$i]{start},$region_list_sm[$i]{end},\@regions_final)}
for(my $i=0;$i<@region_list_l;$i++) {write_region($region_list_l[$i]{start},$region_list_l[$i]{end},\@regions_final)}

format_regions_vector_to_list(\@regions_final,\@final_region_list);
get_p_values_for_region_list(\@final_region_list,
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));

for(my $i=0;$i<@final_region_list;$i++) {
	my ($dominant_tissues,$all_tissues)=tissue_specific_info($final_region_list[$i]{start},
							$final_region_list[$i]{end},
							\@missense_mutations_full_info,
							\@insertion_mutations_full_info,
							\@deletion_mutations_full_info,							
							length($seq));
	$final_region_list[$i]{dominant_tissues}=$dominant_tissues;
	$final_region_list[$i]{all_tissues}=$all_tissues;

	my @dummy_miss;
	my @dummy_ins;
	my @dummy_del;
	for(my $j=1;$j<=length($seq);$j++) {
		$dummy_miss[$j]=0;
		$dummy_ins[$j]=0;
	}
	my $p_miss=get_p_values_for_region($final_region_list[$i]{start},
		$final_region_list[$i]{end},
		\@missense_mutations,
		$total_missense_mutations,
		$average_missense_mut_per_pos,
		\@dummy_ins,0,0,
		\@dummy_del,0,
		length($seq));
	my $p_ins=get_p_values_for_region($final_region_list[$i]{start},
		$final_region_list[$i]{end},
		\@dummy_miss,0,0,
		\@insertion_mutations,
		$total_insertion_mutations,
		$average_insertion_mut_per_pos,
		\@dummy_del,0,
		length($seq));
	my $p_del=get_p_values_for_region($final_region_list[$i]{start},
		$final_region_list[$i]{end},
		\@dummy_miss,0,0,
		\@dummy_ins,0,0,
		\@deletion_mutations,
		$total_deleted_residues,
		length($seq));
	
	$final_region_list[$i]{p_miss}=$p_miss;
	$final_region_list[$i]{p_ins}=$p_ins;
	$final_region_list[$i]{p_del}=$p_del;
}


if($final_region_list[0]) {

	print "# iSiMPRe\n";
	print "# Copyright (c) ";
	print "B. Meszaros, A. Zeke, A Remenyi, I. Simon and Z. Dosztanyi, 2015\n";
	print "# Publication in progress\n";
	print "#\n";
	print "# 1 - Protein ID\n";
	print "# 2 - Region boundaries\n";
	print "# 3 - Region p-value\n";
	print "# 4 - Relative contribution of missense mutations/insertions/deletions to the final p-value\n";
	print "# 5 - p-value calculated from missense mutations only\n";
	print "# 6 - p-value calculated from inseretions only\n";
	print "# 7 - p-value calculated from deletions only\n";
	print "# |\n";
	print "# 9 - Dominant tissues\n";
	print "# |\n";
	print "# 11 - All tissues\n#\n";
}

for(my $i=0;$i<@final_region_list;$i++) {

	if($final_region_list[$i]{pval}>0.01) {next}	
	
	if($final_region_list[$i]{p_miss}==0) {$final_region_list[$i]{p_miss}=10e-300}
	if($final_region_list[$i]{p_ins}==0) {$final_region_list[$i]{p_ins}=10e-300}
	if($final_region_list[$i]{p_del}==0) {$final_region_list[$i]{p_del}=10e-300}
	
	my $log_missp=log($final_region_list[$i]{p_miss});
	my $log_insp=log($final_region_list[$i]{p_ins});
	my $log_delp=log($final_region_list[$i]{p_del});
	my $logp=$log_missp+$log_insp+$log_delp;

	my $miss_weight=$log_missp/$logp;
	if($miss_weight<0.0001) {$miss_weight=0}
	my $ins_weight=$log_insp/$logp;
	if($ins_weight<0.0001) {$ins_weight=0}
	my $del_weight=$log_delp/$logp;
	if($del_weight<0.0001) {$del_weight=0}

	if($final_region_list[$i]{pval}<10e-250) {$final_region_list[$i]{pval}=0}
	if($final_region_list[$i]{p_miss}<10e-250) {$final_region_list[$i]{p_miss}=0}
	if($final_region_list[$i]{p_ins}<10e-250) {$final_region_list[$i]{p_ins}=0}
	if($final_region_list[$i]{p_del}<10e-250) {$final_region_list[$i]{p_del}=0}

	print "$id\t",$final_region_list[$i]{start},"-",$final_region_list[$i]{end},"\t";
	printf("%4.3e\t",$final_region_list[$i]{pval});
	printf("%4.3f/%4.3f/%4.3f\t",$miss_weight,$ins_weight,$del_weight);

	printf("%4.3e\t",$final_region_list[$i]{p_miss});
	printf("%4.3e\t",$final_region_list[$i]{p_ins});
	printf("%4.3e\t|\t",$final_region_list[$i]{p_del});

	if($final_region_list[$i]{dominant_tissues}) {print $final_region_list[$i]{dominant_tissues},"\t|\t";}
	else {print "-\t|\t"}
	print $final_region_list[$i]{all_tissues};
	print "\n";
}


###############
# Subroutines
###############


sub get_del_full_overlap_p {
	my ($seq_len,$del_mut,$del_mut_full_info,$del_full_overlap_p)=@_;
	
	for(my $i=0;$i<@{$del_mut};$i++) {
		my $del_len=$deletion_mutations[$i]{length};

		my $exp_in=round(($del_len/$seq_len)*$del_len);
		my $exp_out=$del_len-$exp_in;
		my $obs_in=$del_len;
		my $obs_out=0;
		my $p=fisher_left($exp_in,$exp_out,$obs_in,$obs_out);
		$del_full_overlap_p->[$seq_len][$del_len]=$p;
	}
}

sub tissue_specific_info {
	my ($start,
		$end,
		$missense_mutations,
		$insertion_mutations,
		$deletion_mutations,
		$len)=@_;

	my %miss_tissue_count;
	my $total_miss_mut_count_in_region=0;
	my $total_miss_mut_count_out_region=0;
	my %ins_tissue_count;
	my $total_ins_mut_count_in_region=0;
	my $total_ins_mut_count_out_region=0;
	my %del_tissue_count;
	my $total_del_mut_count_in_region=0;
	my $total_del_mut_count_out_region=0;

	# Count mutations per tissue types
	# Missense
	for(my $i=0;$i<@{$missense_mutations};$i++) {
		if(($missense_mutations->[$i]{pos}>=$start)&&($missense_mutations->[$i]{pos}<=$end)) {
			$miss_tissue_count{$missense_mutations->[$i]{tissue}}{in_region}++;
			$total_miss_mut_count_in_region++;
		}
		else{
			$miss_tissue_count{$missense_mutations->[$i]{tissue}}{out_region}++;
			$total_miss_mut_count_out_region++;
		}
		$miss_tissue_count{$missense_mutations->[$i]{tissue}}{all}++
	}
	foreach my $key (keys %miss_tissue_count) {
		if(!$miss_tissue_count{$key}{in_region}) {$miss_tissue_count{$key}{in_region}=0}
		if(!$miss_tissue_count{$key}{out_region}) {$miss_tissue_count{$key}{out_region}=0}
		if(!$miss_tissue_count{$key}{all}) {$miss_tissue_count{$key}{all}=0}
	}

	# Insertion
	for(my $i=0;$i<@{$insertion_mutations};$i++) {
		if(($insertion_mutations->[$i]{pos}>=$start)&&($insertion_mutations->[$i]{pos}<=$end)) {
			$ins_tissue_count{$insertion_mutations->[$i]{tissue}}{in_region}++;
			$total_ins_mut_count_in_region++;
		}
		else{
			$ins_tissue_count{$insertion_mutations->[$i]{tissue}}{out_region}++;
			$total_ins_mut_count_out_region++;
		}
		$ins_tissue_count{$insertion_mutations->[$i]{tissue}}{all}++
	}
	foreach my $key (keys %ins_tissue_count) {
		if(!$ins_tissue_count{$key}{in_region}) {$ins_tissue_count{$key}{in_region}=0}
		if(!$ins_tissue_count{$key}{out_region}) {$ins_tissue_count{$key}{out_region}=0}
		if(!$ins_tissue_count{$key}{all}) {$ins_tissue_count{$key}{all}=0}
	}

	# Deletion
	for(my $i=0;$i<@{$deletion_mutations};$i++) {
		for(my $j=$deletion_mutations->[$i]{start};$j<=$deletion_mutations->[$i]{end};$j++) {
			if(($j>=$start)&&($j<=$end)) {
				$del_tissue_count{$deletion_mutations->[$i]{tissue}}{in_region}++;
				$total_del_mut_count_in_region++;
			}
			else{
				$del_tissue_count{$deletion_mutations->[$i]{tissue}}{out_region}++;
				$total_del_mut_count_out_region++;
			}
			$del_tissue_count{$deletion_mutations->[$i]{tissue}}{all}++;
		}
	}
	foreach my $key (keys %del_tissue_count) {
		if(!$del_tissue_count{$key}{in_region}) {$del_tissue_count{$key}{in_region}=0}
		if(!$del_tissue_count{$key}{out_region}) {$del_tissue_count{$key}{out_region}=0}
		if(!$del_tissue_count{$key}{all}) {$del_tissue_count{$key}{all}=0}
	}


	my $total_mut_count_in_region=$total_miss_mut_count_in_region+$total_ins_mut_count_in_region+$total_del_mut_count_in_region;

	# Get tissues present in various mutations
	my @all_keys;
	my @miss_keys=keys(%miss_tissue_count);
	for(my $i=0;$i<@miss_keys;$i++) {
		my $in_all=0;
		for(my $j=0;$j<@all_keys;$j++) {if($miss_keys[$i] eq $all_keys[$j]) {$in_all=1}}
		if($in_all==0) {push(@all_keys,$miss_keys[$i])}
		if($miss_tissue_count{$miss_keys[$i]}{in_region}==0) {
			splice(@miss_keys,$i,1);
			$i--;
			next;
		}
	}
	my @del_keys=keys(%del_tissue_count);
	for(my $i=0;$i<@del_keys;$i++) {
		my $in_all=0;
		for(my $j=0;$j<@all_keys;$j++) {if($del_keys[$i] eq $all_keys[$j]) {$in_all=1}}
		if($in_all==0) {push(@all_keys,$del_keys[$i])}
		if($del_tissue_count{$del_keys[$i]}{in_region}==0) {
			splice(@del_keys,$i,1);
			$i--;
			next;
		}
	}
	my @ins_keys=keys(%ins_tissue_count);
	for(my $i=0;$i<@ins_keys;$i++) {
		my $in_all=0;
		for(my $j=0;$j<@all_keys;$j++) {if($ins_keys[$i] eq $all_keys[$j]) {$in_all=1}}
		if($in_all==0) {push(@all_keys,$ins_keys[$i])}
		if($ins_tissue_count{$ins_keys[$i]}{in_region}==0) {
			splice(@ins_keys,$i,1);
			$i--;
			next;
		}
	}

	# Find the dominant tissue and compile all tissues
	my $all_tissues;
	for(my $i=0;$i<@all_keys;$i++) {
		my $c=0;
		if($miss_tissue_count{$all_keys[$i]}{in_region}) {$c+=$miss_tissue_count{$all_keys[$i]}{in_region}}
		if($ins_tissue_count{$all_keys[$i]}{in_region}) {$c+=$ins_tissue_count{$all_keys[$i]}{in_region}}
		if($del_tissue_count{$all_keys[$i]}{in_region}) {$c+=$del_tissue_count{$all_keys[$i]}{in_region}}
		if($c>0) {
			if(!$all_tissues) {$all_tissues=$all_keys[$i]}
			else {$all_tissues=$all_tissues.', '.$all_keys[$i]}
		}
	}

	my $dominant_tissues;

	for(my $i=0;$i<@all_keys;$i++) {
		my $mut_no=0;
		if($miss_tissue_count{$all_keys[$i]}{in_region}) {$mut_no+=$miss_tissue_count{$all_keys[$i]}{in_region}}
		if($ins_tissue_count{$all_keys[$i]}{in_region}) {$mut_no+=$ins_tissue_count{$all_keys[$i]}{in_region}}
		if($del_tissue_count{$all_keys[$i]}{in_region}) {$mut_no+=$del_tissue_count{$all_keys[$i]}{in_region}}
		if(($mut_no>=($total_mut_count_in_region/4))||($mut_no>100)) {
			if($dominant_tissues) {$dominant_tissues.=", "}
			$dominant_tissues.=$all_keys[$i];
		}
	}
	return($dominant_tissues,$all_tissues);
}




sub amalgamate {
	my ($list1,
	$list2,
	$missense_mutations,
	$total_missense_mutations,
	$missense_average_mut_per_pos,
	$insertion_mutations,
	$total_insertion_mutations,
	$insertion_average_mut_per_pos,
	$deletion_mutations,
	$total_deleted_residues,
	$seq_len,
	$min_extension,
	$min_length_ratio,
	$max_pval_ratio,
	$pval_tolerance_base)=@_;
	
	for(my $i=0;$i<@{$list1};$i++) {
		for(my $j=0;$j<@{$list2};$j++) {
			if(!$list1->[$i]) {last;}
			if(!$list2->[$j]) {last;}

			my $start1=$list1->[$i]{start};
			my $end1=$list1->[$i]{end};
			my $p1=$list1->[$i]{pval};
			if($p1 eq '0') {$p1=1e-300}
			my $len1=$list1->[$i]{end}-$list1->[$i]{start}+1;

			my $start2=$list2->[$j]{start};
			my $end2=$list2->[$j]{end};
			my $p2=$list2->[$j]{pval};
			if($p2 eq '0') {$p2=1e-300}
			my $len2=$list2->[$j]{end}-$list2->[$j]{start}+1;
			
			# The two regions do not overlap
			if(($start1>$end2)||($start2>$end1)) {next;}

			# The two regions are the same
			if(($start1==$start2)&&($end1==$end2)) {next;}

			# Region 2 contains region 1
			if(($start1>=$start2)&&($end1<=$end2)) {
				# Region 2 means a significant extension of region 1
				if(($len2>=($len1+$min_extension))&&($len2>=($min_length_ratio*$len1))) {
					if(($p1<$practically_zero)&&($p2<$practically_zero)) {
						my $mut_num_1=0;
						my $mut_num_2=0;
						for(my $k=$start1;$k<=$end1;$k++) {$mut_num_1+=number_of_mutations_at_position($k,$missense_mutations,$insertion_mutations,$deletion_mutations)}
						for(my $k=$start2;$k<=$end2;$k++) {$mut_num_2+=number_of_mutations_at_position($k,$missense_mutations,$insertion_mutations,$deletion_mutations)}
						
						if($mut_num_2>$mut_num_1+1000) {
							splice(@{$list1},$i,1);
							$i--;
							next;
						}

						my $mut_freq_1=$mut_num_1/($end1-$start1+1);
						my $mut_freq_2=$mut_num_2/($end2-$start2+1);
						
						if($mut_freq_1>$mut_freq_2) {
							splice(@{$list2},$j,1);
							$j--;
							next;
						}
						else {
							splice(@{$list1},$i,1);
							$i--;
							next;
						}
					}
					
					if(($p2/$p1)>$max_pval_ratio) {
						splice(@{$list2},$j,1);
						$j--;
						next;
					}
					else {
						splice(@{$list1},$i,1);
						$i--;
						next;
					}	
				}
				# Region 2 does not mean a significant extension of region 1
				else {
					if($p2<$p1) {
						splice(@{$list1},$i,1);
						$i--;
						next;
					}
					else {
						splice(@{$list2},$j,1);
						$j--;
						next;
					}	
				}
			}

			# Region 1 contains region 2
			if(($start2>=$start1)&&($end2<=$end1)) {
				# Region 1 means a significant extension of region 2
				if(($len1>=($len2+$min_extension))&&($len1>=($min_length_ratio*$len2))) {
					if(($p1<$practically_zero)&&($p2<$practically_zero)) {
						my $mut_num_1=0;
						my $mut_num_2=0;
						for(my $k=$start1;$k<=$end1;$k++) {$mut_num_1+=number_of_mutations_at_position($k,$missense_mutations,$insertion_mutations,$deletion_mutations)}
						for(my $k=$start2;$k<=$end2;$k++) {$mut_num_2+=number_of_mutations_at_position($k,$missense_mutations,$insertion_mutations,$deletion_mutations)}
						
						if($mut_num_2>$mut_num_1+1000) {
							splice(@{$list1},$i,1);
							$i--;
							next;
						}

						my $mut_freq_1=$mut_num_1/($end1-$start1+1);
						my $mut_freq_2=$mut_num_2/($end2-$start2+1);
						
						if($mut_freq_1>$mut_freq_2) {
							splice(@{$list2},$j,1);
							$j--;
							next;
						}
						else {
							splice(@{$list1},$i,1);
							$i--;
							next;
						}
					}

					if(($p1/$p2)>$max_pval_ratio) {
						splice(@{$list1},$i,1);
						$i--;
						next;
					}
					else {
						splice(@{$list2},$j,1);
						$j--;
						next;
					}	
				}
				# Region 1 does not mean a significant extension of region 2
				else {
					if($p1<$p2) {
						splice(@{$list2},$j,1);
						$j--;
						next;
					}
					else {
						splice(@{$list1},$i,1);
						$i--;
						next;
					}	
				}
			}

			# Partial overlap with region 1 coming first
			if((($start2>$start1)&&($start2<$end1))&&($end2>$end1)) {
				my $uniq1=$start2-$start1;
				my $uniq2=$end2-$end1;
				my $common=$end1-$start2+1;
				
				# Insignificant overlap
				if(($uniq1<=($common/2))&&($uniq1<=$min_extension)&&($uniq2<=($common/2))&&($uniq2<=$min_extension)) {
					$list1->[$i]{end}=$list2->[$j]{end};
					$end1=$list1->[$i]{end};
					
					$list1->[$i]{pval}=get_p_values_for_region($start1,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					$p1=$list1->[$i]{pval};
					if($p1 eq '0') {$p1=1e-300}
					splice(@{$list2},$j,1);
					$j--;
					next;
				}
				# Significant extension via region 2
				if(($uniq2>($common/2))&&($uniq2>$min_extension)) {
					my $p_extend=get_p_values_for_region($start1,$end2,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_extend eq '0') {$p_extend=1e-300}

					my $extension_ratio=$uniq2/$common;
					my $pval_tolerance=$pval_tolerance_base**$extension_ratio;
					if(($p_extend/$p1)>$pval_tolerance) {}
					else {
						$list1->[$i]{end}=$list2->[$j]{end};
						$end1=$list1->[$i]{end};
						$list1->[$i]{pval}=$p_extend;
						$p1=$list1->[$i]{pval};
						$uniq2=0;
						$common=$end1-$start2+1;
					}
				}
				# Insignificant extension via region 2
				else {
					my $p_extend=get_p_values_for_region($start1,$end2,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_extend eq '0') {$p_extend=1e-300}
					if($p_extend>$p1) {}
					else {
						$list1->[$i]{end}=$list2->[$j]{end};
						$end1=$list1->[$i]{end};
						$list1->[$i]{pval}=$p_extend;
						$p1=$list1->[$i]{pval};
						$uniq2=0;
						$common=$end1-$start2+1;
					}
				}
				# Significant extension via region 1
				if(($uniq1>($common/2))&&($uniq1>$min_extension)) {
					my $p_shrink=get_p_values_for_region($start2,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_shrink eq '0') {$p_shrink=1e-300}

					my $extension_ratio=$uniq1/$common;
					my $pval_tolerance=$pval_tolerance_base**$extension_ratio;
					if(($p1/$p_shrink)>$pval_tolerance) {
						$list1->[$i]{start}=$list2->[$j]{start};
						$start1=$list1->[$i]{start};
						$list1->[$i]{pval}=$p_shrink;
						$p1=$list1->[$i]{pval};
						$uniq1=0;
						
					}
				}
				# Insignificant extension via region 2
				else {
					my $p_shrink=get_p_values_for_region($start2,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_shrink eq '0') {$p_shrink=1e-300}
					if($p_shrink<$p1) {
						$list1->[$i]{start}=$list2->[$j]{start};
						$start1=$list1->[$i]{start};
						$list1->[$i]{pval}=$p_shrink;
						$p1=$list1->[$i]{pval};
						$uniq1=0;
					}
				}
				if($p1<$p2) {
					splice(@{$list2},$j,1);
					$j--;
				}
				else {
					splice(@{$list1},$i,1);
					$i--;
				}
			}
			# Partial overlap with region 2 coming first
			if((($start1>$start2)&&($start1<$end2))&&($end1>$end2)) {
				my $uniq1=$end1-$end2;
				my $uniq2=$start1-$start2;
				my $common=$end2-$start1+1;
				# Insignificant overlap
				if(($uniq1>($common/2))&&($uniq1>$min_extension)&&($uniq2>($common/2))&&($uniq2>$min_extension)) {
					$list1->[$i]{start}=$list2->[$j]{start};
					$start1=$list1->[$i]{start};

					$list1->[$i]{pval}=get_p_values_for_region($start1,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					$p1=$list1->[$i]{pval};
					if($p1 eq '0') {$p1=1e-300}
					splice(@{$list2},$j,1);
					$j--;
					next;
				}
				# Significant extension via region 1
				if(($uniq1>($common/2))&&($uniq1>$min_extension)) {
					my $p_extend=get_p_values_for_region($start2,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_extend eq '0') {$p_extend=1e-300}

					my $extension_ratio=$uniq1/$common;
					my $pval_tolerance=$pval_tolerance_base**$extension_ratio;
					if(($p_extend/$p2)>$pval_tolerance) {}
					else {
						$list2->[$j]{end}=$list1->[$i]{end};
						$end2=$list2->[$j]{end};
						$list2->[$j]{pval}=$p_extend;
						$p2=$list2->[$j]{pval};
						$uniq1=0;
					}
				}
				# Insignificant extension via region 1
				else {
					my $p_extend=get_p_values_for_region($start2,$end1,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_extend eq '0') {$p_extend=1e-300}
					if($p_extend>$p2) {}
					else {
						$list2->[$j]{end}=$list1->[$i]{end};
						$end2=$list2->[$j]{end};
						$list2->[$j]{pval}=$p_extend;
						$p2=$list2->[$j]{pval};
						$uniq1=0;
					}
				}

				# Significant extension via region 2
				if(($uniq2>($common/2))&&($uniq2>$min_extension)) {
					my $p_shrink=get_p_values_for_region($start1,$end2,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_shrink eq '0') {$p_shrink=1e-300}

					my $extension_ratio=$uniq2/$common;
					my $pval_tolerance=$pval_tolerance_base**$extension_ratio;

					if(($p2/$p_shrink)>$pval_tolerance) {
						$list2->[$j]{start}=$list1->[$i]{start};
						$start2=$list2->[$j]{start};
						$list2->[$j]{pval}=$p_shrink;
						$p2=$list2->[$j]{pval};
						$uniq2=0;
						
					}
				}
				# Insignificant extension via region 2
				else {
					my $p_shrink=get_p_values_for_region($start1,$end2,$missense_mutations,$total_missense_mutations,$missense_average_mut_per_pos,
					$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
					$deletion_mutations,$total_deleted_residues,$seq_len);
					if($p_shrink eq '0') {$p_shrink=1e-300}
					if($p_shrink<$p2) {
						$list2->[$j]{start}=$list1->[$i]{start};
						$start2=$list2->[$j]{start};
						$list2->[$j]{pval}=$p_shrink;
						$p2=$list2->[$j]{pval};
						$uniq2=0;
					}
				}
				if($p1<$p2) {
					splice(@{$list2},$j,1);
					$j--;
				}
				else {
					splice(@{$list1},$i,1);
					$i--;
				}
			}
		}
	}
}

sub get_p_values_for_region_list {
	my ($list,
	$missense_mutations,
	$total_missense_mutations,
	$missense_average_mut_per_pos,
	$insertion_mutations,
	$total_insertion_mutations,
	$insertion_average_mut_per_pos,
	$deletion_mutations,
	$total_deleted_residues,
	$seq_len)=@_;

	for(my $i=0;$i<@{$list};$i++) {
		my $region_length=$list->[$i]{end}-$list->[$i]{start}+1;

		# Calculate observed mutation numbers (missense and insertion)
		my $missense_mut_num_obs=0;
		my $insertion_mut_num_obs=0;
		for(my $j=$list->[$i]{start};$j<=$list->[$i]{end};$j++) {
			$missense_mut_num_obs+=$missense_mutations->[$j];
			$insertion_mut_num_obs+=$insertion_mutations->[$j];
		}
		
		# Calculate expected mutation numbers (missense and insertion)
		my $missense_mut_num_exp=round05($missense_average_mut_per_pos*$region_length);
		my $insertion_mut_num_exp=round05($insertion_average_mut_per_pos*$region_length);
		
		#Calculate p values (missense and insertion)
		my $missense_p_val;
		if(($total_missense_mutations>0)&&($missense_mut_num_exp<=$total_missense_mutations)) {$missense_p_val=fisher_left($missense_mut_num_exp,$total_missense_mutations-$missense_mut_num_exp,$missense_mut_num_obs,$total_missense_mutations-$missense_mut_num_obs)}
		else {$missense_p_val=1}
		my $insertion_p_val;
		if(($total_insertion_mutations>0)&&($insertion_mut_num_exp<=$total_insertion_mutations)) {$insertion_p_val=fisher_left($insertion_mut_num_exp,$total_insertion_mutations-$insertion_mut_num_exp,$insertion_mut_num_obs,$total_insertion_mutations-$insertion_mut_num_obs)}
		else {$insertion_p_val=1}

		$list->[$i]{mis_mut_obs}=$missense_mut_num_obs;
		$list->[$i]{ins_mut_obs}=$insertion_mut_num_obs;
		$list->[$i]{mis_mut_exp}=$missense_mut_num_exp;
		$list->[$i]{ins_mut_exp}=$insertion_mut_num_exp;

		# Iterate through deletions
		my $deletion_p_val=1;
		my $deletion_mut_num_obs=0;
		my $deletion_mut_num_exp=0;
		for(my $k=0;$k<@{$deletion_mutations};$k++) {
			my $del_mut_num_obs=0;
			for(my $j=$list->[$i]{start};$j<=$list->[$i]{end};$j++) {
				if(($j>=$deletion_mutations[$k]->{start})&&($j<=$deletion_mutations[$k]->{end})) {$del_mut_num_obs++}
			}
			if($del_mut_num_obs==0) {next;}
			my $total_del_res=$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1;
			my $del_mut_num_exp=round05(get_exp_deletion_overlap_single($total_del_res,$region_length,$list->[$i]{start},$seq_len));
			$deletion_mut_num_obs+=$del_mut_num_obs;
			$deletion_mut_num_exp+=$del_mut_num_exp;

			my $del_p_val;
			if(($total_del_res>0)&&($del_mut_num_exp<=$total_del_res)) {$del_p_val=fisher_left($del_mut_num_exp,$total_del_res-$del_mut_num_exp,$del_mut_num_obs,$total_del_res-$del_mut_num_obs)}
			else {$del_p_val=1}
			if($del_full_overlap_p[$seq_len][$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1]<$max_deletion_probability) {
				$del_p_val=($del_p_val/$del_full_overlap_p[$seq_len][$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1])*$max_deletion_probability;
			}
			if($del_p_val>1) {$del_p_val=1}
			$deletion_p_val*=$del_p_val;
		}
		my $p_val=$missense_p_val*$insertion_p_val*$deletion_p_val;
		if($p_val<10e-299) {$p_val=10e-300}
		$list->[$i]{pval}=$p_val;
		$list->[$i]{del_mut_obs}=$deletion_mut_num_obs;
		$list->[$i]{del_mut_exp}=$deletion_mut_num_exp;
	}
}

sub get_p_values_for_region {
	my ($start,
	$end,
	$missense_mutations,
	$total_missense_mutations,
	$missense_average_mut_per_pos,
	$insertion_mutations,
	$total_insertion_mutations,
	$insertion_average_mut_per_pos,
	$deletion_mutations,
	$total_deleted_residues,
	$seq_len)=@_;

	my $region_length=$end-$start+1;

	# Calculate observed mutation numbers (missense and insertion)
	my $missense_mut_num_obs=0;
	my $insertion_mut_num_obs=0;
	for(my $i=$start;$i<=$end;$i++) {
		$missense_mut_num_obs+=$missense_mutations->[$i];
		$insertion_mut_num_obs+=$insertion_mutations->[$i];
	}

	# Calculate expected mutation numbers (missense and insertion)
	my $missense_mut_num_exp=round05($missense_average_mut_per_pos*$region_length);
	my $insertion_mut_num_exp=round05($insertion_average_mut_per_pos*$region_length);

	#Calculate p values (missense and insertion)
	my $missense_p_val;
	if(($total_missense_mutations>0)&&($missense_mut_num_exp<=$total_missense_mutations)) {$missense_p_val=fisher_left($missense_mut_num_exp,$total_missense_mutations-$missense_mut_num_exp,$missense_mut_num_obs,$total_missense_mutations-$missense_mut_num_obs)}
	else {$missense_p_val=1}
	my $insertion_p_val;
	if(($total_insertion_mutations>0)&&($insertion_mut_num_exp<=$total_insertion_mutations)) {$insertion_p_val=fisher_left($insertion_mut_num_exp,$total_insertion_mutations-$insertion_mut_num_exp,$insertion_mut_num_obs,$total_insertion_mutations-$insertion_mut_num_obs)}
	else {$insertion_p_val=1}

	# Iterate through deletions
	my $deletion_p_val=1;
	for(my $k=0;$k<@{$deletion_mutations};$k++) {
		my $deletion_mut_num_obs=0;
		for(my $i=$start;$i<=$end;$i++) {
			if(($i>=$deletion_mutations[$k]->{start})&&($i<=$deletion_mutations[$k]->{end})) {$deletion_mut_num_obs++}
		}
		if($deletion_mut_num_obs==0) {next;}
		my $total_del_res=$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1;
		my $deletion_mut_num_exp=round05(get_exp_deletion_overlap_single($total_del_res,$region_length,$start,$seq_len));
		my $del_p_val;
		if(($total_del_res>0)&&($deletion_mut_num_exp<=$total_del_res)) {$del_p_val=fisher_left($deletion_mut_num_exp,$total_del_res-$deletion_mut_num_exp,$deletion_mut_num_obs,$total_del_res-$deletion_mut_num_obs)}
		else {$del_p_val=1}
		if($del_full_overlap_p[$seq_len][$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1]<$max_deletion_probability) {
			$del_p_val=($del_p_val/$del_full_overlap_p[$seq_len][$deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1])*$max_deletion_probability;
		}
		if($del_p_val>1) {$del_p_val=1}
		$deletion_p_val*=$del_p_val;
	}
	my $p_val=$missense_p_val*$insertion_p_val*$deletion_p_val;
	if($p_val==0) {$p_val=10e-400}
	return($p_val);
}

sub scan_for_regions {
	my ($region_length,
	$seq_len,
	$final_regions,
	$probability_cutoff,
	$missense_mutations,
	$total_missense_mutations,
	$missense_average_mut_per_pos,
	$insertion_mutations,
	$total_insertion_mutations,
	$insertion_average_mut_per_pos,
	$deletion_mutations,
	$total_deleted_residues)=@_;

	# Evaluate all possible regions
	for(my $i=1;$i<=$seq_len-$region_length+1;$i++) {

		# Check overlap with existing regions
		my $overlap=read_region($i,$i+$region_length-1,$final_regions);
		if($overlap>=$region_length-1) {next;}

		my $p_val=get_p_values_for_region($i,$i+$region_length-1,$missense_mutations,$total_missense_mutations,
		$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
		$deletion_mutations,$total_deleted_residues,$seq_len);

		if($p_val>$probability_cutoff) {next;}

		my ($region_start,$region_end);
		($region_start,$region_end,$p_val)=extend_region($i,
							$i+$region_length-1,
							$missense_mutations,
							$total_missense_mutations,
							$missense_average_mut_per_pos,
							$insertion_mutations,
							$total_insertion_mutations,
							$insertion_average_mut_per_pos,
							$deletion_mutations,
							$total_deleted_residues,
							$seq_len,
							$p_val);
		($region_start,$region_end,$p_val)=extend_region($region_start,
							$region_end,
							$missense_mutations,
							$total_missense_mutations,
							$missense_average_mut_per_pos,
							$insertion_mutations,
							$total_insertion_mutations,
							$insertion_average_mut_per_pos,
							$deletion_mutations,
							$total_deleted_residues,
							$seq_len,
							$p_val);
		write_region($region_start,$region_end,$final_regions);
	}
}

sub number_of_mutations_at_position {
	my ($position,$missense_mutations,$insertion_mutations,$deletion_mutations)=@_;
	if($position<=0) {return(0)}
	
	my $miss=0;
	my $ins=0;
	my $del=0;
	
	if($missense_mutations->[$position]) {$miss=$missense_mutations->[$position]}
	if($insertion_mutations->[$position]) {$ins=$insertion_mutations->[$position]}
	for(my $k=0;$k<@{$deletion_mutations};$k++) {
		if(($position>=$deletion_mutations[$k]->{start})&&($position<=$deletion_mutations[$k]->{end})) {
			$del+=1/($deletion_mutations[$k]->{end}-$deletion_mutations[$k]->{start}+1)
		}
	}
	my $mut_number=$miss+$ins+$del;
	return($mut_number);
}

sub extend_region {
	my ($start,
	$end,
	$missense_mutations,
	$total_missense_mutations,
	$missense_average_mut_per_pos,
	$insertion_mutations,
	$total_insertion_mutations,
	$insertion_average_mut_per_pos,
	$deletion_mutations,
	$total_deleted_residues,
	$seq_len,
	$p_val)=@_;
	
	my $right_extended=0;
	my $left_extended=0;

	# Extending to the right
	my $stop_signal=0;
	if($end<$seq_len) {
		my $max_mut_freq=0;
		while($stop_signal==0) {

			my $prev_mut_num=0;
			for(my $i=$start;$i<=$end;$i++) {$prev_mut_num+=number_of_mutations_at_position($i,$missense_mutations,$insertion_mutations,$deletion_mutations)}
			my $prev_mut_freq=$prev_mut_num/($end-$start+1);
			if($prev_mut_freq>$max_mut_freq) {$max_mut_freq=$prev_mut_freq}
			
			$end++;
			my $prev_p_val=$p_val;

			my $new_mut_number=number_of_mutations_at_position($end,$missense_mutations,$insertion_mutations,$deletion_mutations);
			if($new_mut_number==0) {
				$end--;
				$stop_signal=1;
				next;
			}
			my $new_mut_freq=($prev_mut_num+$new_mut_number)/($end-$start+1);

			$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
			$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
			$deletion_mutations,$total_deleted_residues,$seq_len);

			if(($new_mut_freq*$tolerated_mutation_freq_drop_in_extension<$max_mut_freq)&&($p_val>=$prev_p_val)) {
				$end--;
				$stop_signal=1;
				next;
			}
			if($p_val<=$prev_p_val) {$right_extended=1;}
			else {
				$end--;
				$stop_signal=1;
				$p_val=$prev_p_val;
			}
			if($end==$seq_len) {$stop_signal=1}
			
		}
	}

	# Extending to the left
	$stop_signal=0;
	if($start>1) {
		my $max_mut_freq=0;
		while($stop_signal==0) {
			my $prev_mut_num=0;
			for(my $i=$start;$i<=$end;$i++) {$prev_mut_num+=number_of_mutations_at_position($i,$missense_mutations,$insertion_mutations,$deletion_mutations)}
			my $prev_mut_freq=$prev_mut_num/($end-$start+1);
			if($prev_mut_freq>$max_mut_freq) {$max_mut_freq=$prev_mut_freq}

			$start--;
			my $prev_p_val=$p_val;

			my $new_mut_number=number_of_mutations_at_position($start,$missense_mutations,$insertion_mutations,$deletion_mutations);
			if($new_mut_number==0) {
				$start++;
				$stop_signal=1;
				next;
			}
			my $new_mut_freq=($prev_mut_num+$new_mut_number)/($end-$start+1);

			$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
			$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
			$deletion_mutations,$total_deleted_residues,$seq_len);

			if(($new_mut_freq*$tolerated_mutation_freq_drop_in_extension<$max_mut_freq)&&($p_val>=$prev_p_val)) {
				$start++;
				$stop_signal=1;
				next;
			}
			if($p_val<=$prev_p_val) {$left_extended=1;}
			else {
				$start++;
				$stop_signal=1;
				$p_val=$prev_p_val;
			}
			if($end==$seq_len) {$stop_signal=1}
		}
	}

	# Shrinking from the right
	$stop_signal=0;
	if($right_extended==0) {
		my $max_mut_freq=0;
		while($stop_signal==0) {
			my $prev_mut_num=0;
			for(my $i=$start;$i<=$end;$i++) {$prev_mut_num+=number_of_mutations_at_position($i,$missense_mutations,$insertion_mutations,$deletion_mutations)}
			my $prev_mut_freq=$prev_mut_num/($end-$start+1);
			if($prev_mut_freq>$max_mut_freq) {$max_mut_freq=$prev_mut_freq}

			my $prev_p_val=$p_val;
			my $new_mut_number=number_of_mutations_at_position($end,$missense_mutations,$insertion_mutations,$deletion_mutations);
			if($new_mut_number==0) {
				$end--;
				$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
				$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
				$deletion_mutations,$total_deleted_residues,$seq_len);
				next;
			}
			my $new_mut_freq=($prev_mut_num+$new_mut_number)/($end-$start+1);

			$end--;
			if($start>$end) {
				$end++;
				last;
			}

			$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
			$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
			$deletion_mutations,$total_deleted_residues,$seq_len);

			if(($new_mut_freq*$tolerated_mutation_freq_drop_in_extension<$max_mut_freq)&&($p_val>=$prev_p_val)) {
				$end++;
				$stop_signal=1;
				next;
			}
			if($p_val<=$prev_p_val) {}
			else {
				$end++;
				$stop_signal=1;
				$p_val=$prev_p_val;
			}
		}
	}

	# Shrinking from the left
	$stop_signal=0;
	if($left_extended==0) {
		my $max_mut_freq=0;
		while($stop_signal==0) {
			my $prev_mut_num=0;
			for(my $i=$start;$i<=$end;$i++) {$prev_mut_num+=number_of_mutations_at_position($i,$missense_mutations,$insertion_mutations,$deletion_mutations)}
			my $prev_mut_freq=$prev_mut_num/($end-$start+1);
			if($prev_mut_freq>$max_mut_freq) {$max_mut_freq=$prev_mut_freq}

			my $prev_p_val=$p_val;
			my $new_mut_number=number_of_mutations_at_position($start,$missense_mutations,$insertion_mutations,$deletion_mutations);
			if($new_mut_number==0) {
				$start++;
				$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
				$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
				$deletion_mutations,$total_deleted_residues,$seq_len);
				next;
			}
			my $new_mut_freq=($prev_mut_num+$new_mut_number)/($end-$start+1);

			$start++;
			if($start>$end) {
				$start--;
				last;
			}

			$p_val=get_p_values_for_region($start,$end,$missense_mutations,$total_missense_mutations,
			$missense_average_mut_per_pos,$insertion_mutations,$total_insertion_mutations,$insertion_average_mut_per_pos,
			$deletion_mutations,$total_deleted_residues,$seq_len);

			if(($new_mut_freq*$tolerated_mutation_freq_drop_in_extension<$max_mut_freq)&&($p_val>=$prev_p_val)) {
				$start--;
				$stop_signal=1;
				next;
			}

			if($p_val<=$prev_p_val) {}
			else {
				$start--;
				$stop_signal=1;
				$p_val=$prev_p_val;
			}
		}
	}
	return($start,$end,$p_val);
}

sub format_regions_vector_to_list {
	my ($vector,$list)=@_;
	my $prev=0;
	my ($start,$end);
	my $count=0;
	my $len;
	for(my $i=1;$i<@{$vector};$i++) {
		$len=$i;
		if(($vector->[$i]==1)&&($prev==0)) {
			$start=$i;
			$prev=1;
		}
		if(($vector->[$i]==0)&&($prev==1)) {
			$end=$i-1;
			$prev=0;
			$list->[$count]{start}=$start;
			$list->[$count]{end}=$end;
			$count++;
		}
	}
	if($prev==1) {
		$list->[$count]{start}=$start;
		$list->[$count]{end}=$len;
	}
}

sub read_region {
	my ($start,$end,$regions)=@_;
	my $count=0;
	for(my $i=$start;$i<=$end;$i++) {$count+=$regions->[$i];}
	return($count);
}

sub write_region {
	my ($start,$end,$vector)=@_;
	for(my $i=$start;$i<=$end;$i++) {$vector->[$i]=1;}
}

sub get_exp_deletion_overlap_multi {
	my ($region_start_position,$region_length,$deletions,$protein_length)=@_;

	my $overlap=0;
	for(my $i=0;$i<@{$deletions};$i++) {$overlap+=get_exp_deletion_overlap_single($deletions->[$i]{length},$region_length,$region_start_position,$protein_length);}
	return($overlap);
}

sub get_exp_deletion_overlap_single {
	my ($del_length,$region_length,$region_start_position,$protein_length)=@_;

	my $core_overlap=((abs($del_length-$region_length)+1)*min($del_length,$region_length))/$protein_length;
	my $side_overlap=min($del_length,$region_length)*(min($del_length,$region_length)-1)/$protein_length;
	my $edge_corr=0;
	if($region_start_position<$del_length) {
		$edge_corr=(($del_length-$region_start_position)*($del_length-$region_start_position+1))/(2*$protein_length);
	}
	elsif(($protein_length-$region_start_position-$region_length+2)<$del_length) {
		$edge_corr=(($del_length-$protein_length+$region_start_position+$region_length-2)*($del_length-$protein_length+$region_start_position+$region_length-1))/(2*$protein_length);
	}
	
	my $exp_overlap=$core_overlap+$side_overlap-$edge_corr;
	if($exp_overlap<0) {$exp_overlap=0}
	return($exp_overlap);
}


sub min {return(($_[0],$_[1])[$_[0]>$_[1]])}


sub fisher_left {
my ($n11,$n12,$n21,$n22)=@_;

	my $npp = $n11+$n12+$n21+$n22;
	my $n1p = $n11+$n12;
	my $np1 = $n11+$n21;

	my $left_value = calculateStatistic( n11=>$n11,
        	                          n1p=>$n1p,
                	                  np1=>$np1,
                        	          npp=>$npp);

	if( (my $errorCode = getErrorCode())) {
		print STDERR $errorCode." - ".getErrorMessage();
		$left_value='-';
	}
	return($left_value);
}

sub round {
	my $num=shift;
	return(int(0.5+$num));
}


sub round05 {
	my $num=shift;
	return(int(0.5+$num));
}


############################
# Installation of iSiPMRe: #
############################

iSiMPRe is written in Perl and therefore does not need to be installed or compiled. However, it relies on
certain Perl modules and an external program (TRF). These are included with the downloadable version of
ISiMPRe and can be installed/set up as described below:

I. Install the Text::NSP package for Perl. iSiMPRe uses the Fisher test module of the package
(http://search.cpan.org/dist/Text-NSP-1.07/lib/Text/NSP/Measures/2D/Fisher/left.pm). There are various
approaches to installing this package:
a. Installation can be done via CPAN, for a description see: http://www.cpan.org/modules/INSTALL.html
b. Installation can be done via certain package managers, such as apt-get (Ubuntu) or yum (Fedora). Check
your OS's package manager to see if this is a viable option for you.
c. Alternatively you can just use the NSP package files in the 'modules' directory supplied with iSiMPRe.
These files have to be in a directory that is in the @INC environment variable of your Perl installation.
You can either copy/move the contents of the 'modules' directory to a directory already in @INC or you can
add the 'modules' directory to @INC (for a description see e.g. http://www.perlmonks.org/?node_id=923351).
While the contents of @INC can differ between users, directories like '/usr/share/perl5' are quite
ubiquitious. Therefore for an easy installation one can try simply copying the contents of 'modules' there,
like:
`sudo cp -r <PATH_TO_iSiMPRe>/modules/* /usr/share/perl5/`
This usually suffices for iSiMPRe to run.

II. Set up TRF (https://tandem.bu.edu/trf/trf.html). TRF (Tandem Repeats Finder) is necessary for the low
complexity filtering of mutations. TRF  is a standalone program available for free download from the given
link. The 64 bit Linux version is included in the iSiMPRe download. It should consist of a single executable
file (trf407b.linux64) located in the TRF subdirectory of the iSiMPRe directory.
iSiMPRe tries to use TRF by running it on a cDNA sequence to locate low complexity regions. However, if no
cDNA sequence file is provided of TRF is not found/not executable, iSiMPRe simply skips the low complexity
filtering step (together with a warning) and proceeds to determine the significantly mutated regions
calculated from all mutations.


Provided that the Fisher left module from the NSP package is installed, iSiMPRE should work.
The syntax is the following:
`perl iSiMPRe.pl <Protein name> <missense mutation file> <indel file> <protein sequence file in FASTA format>
          <cDNA sequence file in FASTA format>`
cDNA sequence file is optional and can be omitted.

The program directory includes data for two example proteins with the mutations from the version 73 of
COSMIC. These can be tested with executing the commands in the iSiMPRe directory:
`perl iSiMPRe.pl MED12 mutations-missense.txt mutations-indels.txt sequence_MED12-protein.fasta sequence_MED12-cDNA.fasta` and
`perl iSiMPRe.pl CEBPA mutations-missense.txt mutations-indels.txt sequence_CEBPA-protein.fasta sequence_CEBPA-cDNA.fasta`


########################
# Format requirements: #
########################

The format of the input files should be as follows:


I. Missense mutations

The file containing the missense mutations should contain at least 4 columns separated by tabs, containig the
following data:
 1 - Protein ID
 2 - Position of the mutation in the protein
 3 - Description of the mutation - this is optional
 4 - Tissue/cancer type - this is optional
The file may contain other columns as well, these will be ignored by iSiMPRe.


II. Indel mutations

Insertions and deletions should be specified in the same file. The file should contain at least 4 columns
separated by tabs, containig the following data:
 1 - Protein ID
 2 - Position/boundaries of the mutation in the protein. For insertions these should be two consecutive numbers separated by a '-'. For deletions this should be the starting and the end point of the deletion, also separated by '-'.
 3 - Description of the mutation, should begin with 'del' or 'ins' but can be extended (see example file)
 4 - Tissue/cancer type - this is optional
The file may contain other columns as well, these will be ignored by iSiMPRe.


III. Protein/cDNA sequence files

Protein/cDNA sequence files should be in standard FASTA format. For a description, see:
http://www.ncbi.nlm.nih.gov/BLAST/blastcgihelp.shtml

